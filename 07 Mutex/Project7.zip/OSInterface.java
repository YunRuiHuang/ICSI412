public interface OSInterface extends ProcessInterface, Device, MemoryInterface, Mutex {
}

public enum PriorityEnum {
    RealTime, Interactive, Background
}

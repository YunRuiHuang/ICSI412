public class RescheduleException extends Exception {
}

public abstract class UserlandProcess {
    public abstract RunResult run();
}


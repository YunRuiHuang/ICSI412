public class RunResult {
    public boolean ranToTimeout;
    public int millisecondsUsed;
}
